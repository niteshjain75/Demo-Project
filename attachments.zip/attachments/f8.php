<?php 
$con=mysqli_connect("localhost","root","","data");
if(!$con)
{
	die("connection not esstablish". mysqli_error($con));
}

if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$city=$_POST['city'];
	 $s="select * from data1 where Name like '%$name%' and City like '%$city%' ";
	$result=mysqli_query($con,$s);
}
else
{
	$s="select * from data1";
    $result=mysqli_query($con,$s);
}
?>
<form method="post" action="">
<input type="text" name="name"/><input type="text" name="city"/><input type="submit" name="submit" value="go"/><br>
</form>

<?php

echo"<table border='2px' width='100%'><tr><th>id</th>  <th>name</th> <th> email</th> <th>address</th><th>city</th><th> mobile</th></tr>";
while($row=mysqli_fetch_array($result))
{
	echo"<tr>";
	echo"<td>".$row['id']."</td><td>" .$row['name']."</td><td>".$row['email']."</td><td>".$row['address']."</td><td>".$row['city']."</td><td>".$row['mobile']."</td>";
		echo"</tr>";
	
}
echo"</table>";





?>