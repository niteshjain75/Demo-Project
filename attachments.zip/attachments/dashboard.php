<?php 
include("heading.php");
/* header section*/
?>
<!--  content-->
<?php
if($_SESSION['email']==true)
{
echo "<p style='color:white;'>welcome"."".$_SESSION['name']."<p>";
}
else
{
header('location:login.php'); 

}
?><!--  container start-->
  <div class="container"> 
  <!--column 12-->
 <div class="col-md-12">
   <!--  Heading-->
   <h1> Dashboard</h1>
  <!--  column close -->
  </div>
  <!--  container close-->																	
    </div>
  <!--  container start-->
     <div class="container"> 
    <!-- raw  column -->
    <div class ="raw">
    <!--  column 1  div col-md-3 -->
	 <div class="col-md-3" >
	   <!--  div start-->
 <div style=" box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); padding: 16px; text-align: center; background-color: #bb86fc; color: white;">
     <!--  Heading-->
  <h3>11+</h3>
<!--  anchor tag in paragraph-->
<p><a href="partners.php" style="color:white;">Partners</a></p>
 <!--  div   stop-->            
</div>
 <!--  column 2   div    col-md-3   close-->
                                                                                           </div>
 <!--  column 3 div col-md-3 -->          
  <div class="col-md-3" >
<!--  div start-->
<div style=" box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); padding: 16px; text-align: center ; background-color: #90CAF9;color: white;">
  <!--  Heading-->
   <h3>55+</h3>
  <!--  anchor tag in paragraph--> 
<p style="color:white;">Projects</p>
   <!--  div   stop-->      
</div>
  <!--  column 2   div    col-md-3   close--> 
</div>
 <!--  column 3   div    col-md-3   start-->
  <div class="col-md-3">
  <!--  div start-->
<div	style=" box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); padding: 16px; text-align: center; background-color: #ffaf49; color: white;">
    <!--  Heading-->     
<h3>100+</h3>
 <!--  anchor tag in paragraph--> 
<p> <a href="contact.php"  style="color:white;">Contact</a></p>
  <!--  div   stop-->       
</div>
 <!--  column 3   div    col-md-3   close-->
</div>
  <!--  column 4  div    col-md-3   start--> 
<div class="col-md-3" >
 <!--  div start-->
<div style=" box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); padding: 16px;  text-align: center;  background-color: #03DAC5;  color: white;  ">
    <!--  Heading--> 
  <h3>100+</h3>
   <!--  anchor tag in paragraph--> 
<p> <a href="#"style="color:white;">Reports</a></p>
    <!--  div   stop-->    
	</div>
  <!--  column 4 div    col-md-3   close-->
</div>
  <!--  raw column close-->
 </div>
     <!--  container close-->
		 </div>
         </br>
   <!--  container start-->
   <div class="container">
                    <!--  Raw column-->
	<div class="raw">
                    <!--  column 1  col-md-6 -->
<div class="col-md-6">
                      <!--put image-->                                  
      <img src="grap.jpg" style=" width:500px; height:400px;">
       <!--  column  col-md - close-->
		</div>
       <!--  column 2  col-md-6 -->
	 <div class="col-md-6">
       <!--put image-->    
<img src="grap1.png"  style=" width:500px; height:400px;">
  <!--  column  col-md - close-->
			</div>
                                                                                            <!--  raw column close-->
																								</div>
 <!--  Container Stop-->
</div>
<?php 
include("footers.php");
/* footer section*/                                                                                
?>

