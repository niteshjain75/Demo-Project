-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2019 at 07:18 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data`
--

-- --------------------------------------------------------

--
-- Table structure for table `data1`
--

CREATE TABLE `data1` (
  `id` int(23) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(76) NOT NULL,
  `password` varchar(33) NOT NULL,
  `address` varchar(98) NOT NULL,
  `city` varchar(67) NOT NULL,
  `mobile` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data1`
--

INSERT INTO `data1` (`id`, `name`, `email`, `password`, `address`, `city`, `mobile`) VALUES
(14, 'jay', 'jay@gmail.com', '123', 'jayanagar', 'Mumbai', 0),
(43, 'trtrtrtrtrtrtrtrtrtrtrtrtrtrtrtrtrtrtrtr', 'rewwwwwww@gmail.com', '122233', 'eew ', 'Mumbai', 46877),
(44, 'abcd', 'abcd@gmail.com', '123', 'ssssssssssss', 'Delhi', 72222222),
(90, 'dsdd', 'dasdd@gmail.com', '1111111111111', 'dddddddddd', 'Mumbai', 92278787),
(95, 'rerer', 'rrrr@gmail.com', 'we', 'wee', 'Mumbai', 111),
(101, 'kirti', 'kirti@gmail.com', '123', 'sdsd', 'Mumbai', 87655552),
(107, 'weee', 'ddjd@gmal.com', '22222222222', 'dddddddddddddddd', 'Delhi', 5566444),
(109, 'Sodhi', 'sodhi@gmail.com', '123', 'gcc  nsd jssss', 'Delhi', 9876454544),
(111, 'Nitin Kumar', 'nitin@gmail.com', '12345', 'Jaya Nagr', 'Bangalore', 7898786756),
(112, 'Amit', 'amit@gmail.com', '12345', 'Jaya Nagar', 'Bangalore', 879878765),
(113, 'qeeeqee', 'wqwe@gmail.com', '8986633', 'uewewuie', 'Delhi', 5686443333),
(114, 'JOE', 'joe@gmail.com', '123456', 'sd', 'Mumbai', 8767675456),
(115, 'Akita', 'akita@gmail.com', '123456', 'Jaipur House', 'Delhi', 9383434222),
(119, 'Annay', 'annay@gmail.com', 'annayjain', 'Nehru Nagar', 'Delhi', 9876543210),
(120, 'amita jain', 'amitas@gmail.com', '123321123', 'dddddddddd', 'Mumbai', 786594494434),
(121, 'vipul', 'vipuljain@gmail.com', '123456789', 'ghtht', 'Delhi', 7756575757467);

-- --------------------------------------------------------

--
-- Table structure for table `data2`
--

CREATE TABLE `data2` (
  `id` int(24) NOT NULL,
  `name` varchar(55) NOT NULL,
  `email` varchar(67) NOT NULL,
  `subject` varchar(555) NOT NULL,
  `mobile` bigint(12) NOT NULL,
  `address` varchar(98) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data2`
--

INSERT INTO `data2` (`id`, `name`, `email`, `subject`, `mobile`, `address`) VALUES
(11, 'Ravi', 'ravi@gmail.com', 'detydfdvgx', 78445533776, 'Bangalore'),
(12, 'abhijeet', 'abhijeet@gmail.com', 'double', 877345635, ''),
(13, 'Abhishek Hebbar', 'abhishek@gmail', 'Furniture dealers', 988654123, '#734, JP nagar 2nd Phase, Bangalore'),
(14, 'Raman@gmail.com', 'reeee@gmail.com', 'email Query', 8767766988, 'Delhi'),
(15, 'Tarun ', 'Tarun@gmail.com', 'Server Query', 89778879799, 'Kolkata'),
(16, 'UWANG', 'umang@gmail.com', 'Networking Services ', 8787464893, 'Surat'),
(17, 'Garima', 'garima@gmail.com', 'Technical Support', 78688744121, 'Bangalore'),
(18, 'Hitesh ', 'hitesh@gmail.com', 'Technical Support', 7844345764, 'Bangalore'),
(20, 'Yati', 'yati@gmail.com', 'Technical Error', 89757884748, 'Mumbai'),
(21, 'MAHESH', 'mahesh@gmail.com', '', 6987778764, 'Pune'),
(23, 'Pranit', 'pranit@gmail.com', 'Technical Error', 7876767643, 'Bangalore'),
(24, 'Varnit', 'varnit@gmail.com', 'hfgg', 877663432, 'Pune'),
(25, 'AMAR', 'amar@gmail.com', 'tytyeopeyhfbfbcx', 786432233, 'Bangalore'),
(26, 'Lokesh', 'lokesh@gmail.com', '', 9408797224, 'Delhi'),
(27, 'Naman', 'naman@gmail.com', 'Voice Support', 7866453733, 'Delhi'),
(28, 'Om', 'omi@gmail.com', 'techical support', 672223776, 'Noida'),
(30, 'Akash', 'as@gmail.com', 'Tech', 8336732222, 'Bangalore'),
(31, 'Sammi', 'sam@gmail.com', 'technical support', 8987332225, 'pune'),
(32, 'Parag', 'par@gmail.com', 'Voice Support', 9370333488, 'Bangalore'),
(33, 'Sakit', 'sak@gmail.com', 'sss', 863337673, 'Noida'),
(34, 'Yugank', 'yug@gmail.com', '', 8646745634, 'Pune'),
(35, 'Shubham', 'shu@gmail.com', 'voice support', 8446338255, 'Noida'),
(36, 'erreeeeee', 'feeeeeeeeeee@gmail.com', 'cdcccccccccccccccc', 7834647833, 'cdfefr3d'),
(37, 'euevgrfrehshg', 'fvg4rtgr@gmail.com', 'sqfffffffffffff', 8557754444, 'ffffffffffffffffffe'),
(38, 'tyech ', 'tech@gmail.com', 'voice query', 9876567566, 'bangalore'),
(39, 'Saa', 'aaaa!@gmail.com', 'sadd', 9888222222, 'ddsd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data1`
--
ALTER TABLE `data1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `data2`
--
ALTER TABLE `data2`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data1`
--
ALTER TABLE `data1`
  MODIFY `id` int(23) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `data2`
--
ALTER TABLE `data2`
  MODIFY `id` int(24) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
