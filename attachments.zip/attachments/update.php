<?php 
include("heading.php");
/* Header  Section*/
?> 
<?php
if($_SESSION['email']==true)
{
echo "<p style='color:white;'>welcome"."".$_SESSION['name']."<p>";
}
else
{
header('location:login.php'); 

}
?>
<!-- Content-->
<?PHP 
/* Record  Update  query */
$con=mysqli_connect("localhost","root","","data");
if(!$con)
{
	die("connection not establish" .mysqli_error($con));
	
}

if (isset($_POST['submit']))
{
	
	$a=$_POST['id'];
	$b=$_POST['name'];
	$c=$_POST['email'];
	$d=$_POST['subject'];
	$e=$_POST['mobile'];
	$f= $_POST['address'];
	
	$s="update data2 set name='".$_POST['name']."', email='$c', subject='$d', mobile='$e', address='$f' where id='$a'";
            if(mysqli_query($con,$s))
{
	echo"<script>  alert('Record Update');</script>   ";
	echo" <a href='partners.php'></a>";
}
	else
	{
		echo "Error".mysqli_error($con);
}
	
	
	
}

/* select  query*/
 $s="select * from data2 where id='".$_GET['id']."' ";
$result=mysqli_query($con,$s);
$row=mysqli_fetch_array($result);
?>
   <!-- Container Div -->
   
                            <div class="container">
<!--Heading-->
                <h1 style="text-indent:-.5em;">Detail Update </h1>

<!--Raw  section-->
<div class="row">

<!--col -md -6-->
                 <div class="col-md-6"  >
<!--Form  Start-->				 
                      <form class="form-horizontal" method="post" >
<!--ID-->					  
                   <div class="form-group">
                            <label for="exampleInputName2" style="font-size:12px;" >	Id</label>
                            <input type="text" class="form-control"  placeholder="Name"  name="id"  value="<?php  echo $row['id'];?>"style="width:500px;">
                        </div>
<!--Business Name-->						
                      <div class="form-group">
                                  <label for="exampleInputName2" style="font-size:12px;" >	Business Name</label>
                                  <input type="text" class="form-control"  placeholder="Name"  name="name" value="<?php echo $row['name']; ?>" style="width:500px;">
                           </div>
 <!--Email-->
                        <div class="form-group">
                                            <label for="exampleInputName2"style="font-size:12px;" >Company Email</label>
                                  <input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Email" value="<?php echo $row['email']; ?>" style="width:500px;">
                            </div>
<!--Mobile Number-->
                <div class="form-group">
                                      <label for="exampleInputName2" style="font-size:12px;" >	Mobile Number</label>
                            <input type="text" class="form-control" id="exampleInputName2" placeholder="Enter your Number"  name="mobile"   value="<?php  echo $row['mobile'];?>" style="width:500px;">
                                 </div>
  
   <!--Subject-->
                        <div class="form-group">
                                       <label for="exampleInputName2" style="font-size:12px;" >	Subject</label>
                                  <input type="text" class="form-control" id="exampleInputName2" placeholder="Subject"  name="subject" value="<?php echo $row['subject'];?>" style="width:500px;">
                            </div>
   

  <!--Address-->
                              <div class="form-group ">
                                                  <label class=" control-label" for="formGroupInputLarge" style="font-size:12px;" > Address</label>
                                        <textarea class="form-control" rows="4" name="address" placeholder="Enter your address"   value=" <?php echo $row['address']; ?>" style="width:500px;"><?php echo $row['address']; ?></textarea>
                                 </div>
  
<!--div for button-->

                                        <div class="col-sm-8">
  <!--2 buttons   SAVE & Clear-->   
	                                    <button type="submit" class="btn btn-success" name="submit">Save</button>
	                                   <button type="submit" class="btn btn-primary" name="clear">Clear</button>
	<!--Button Div CLOSE-->   
                        </div>
  

<!--Col-md-DIV Close-->
                      </div>
					  <!--Raw Div close-->					  
                                              </div>
	<!--container Div close-->										  
                            </div>
							<!--Content Close-->
							
<?php 
include("footers.php");
/* Footer  Section*/
?> 