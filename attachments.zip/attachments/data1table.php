<?php 
include("heading.php");
?> 



<?php 

$con=mysqli_connect("localhost","root","","data");
if(!$con)
{
	die("connection not esstablish".mysqli_error($con));
	
} 
{
$k="select * from data1";
$result=mysqli_query($con,$k);
}
echo "  <button type='submit' class='btn btn-default' ><a href='partner_addnew.php'>Add Members</a></button>";
echo"<div class='container'><table  class='table table-bordered' style='font-size:14px;'><tr><th>Id</th><th>Name</th>  <th>EmailId</th> <th> Address</th> <th>City</th><th>Mobile</th></tr>";
while($row=mysqli_fetch_array($result))
{
	echo"<tr ><td>".$row['id']."</td><td>".$row['name']."</td><td>" .$row['email']."</td><td>".$row['address']."</td><td>".$row['city']."</td><td>".$row['mobile']."</td></tr>";

	
}
echo"</table></div>";

?>

<?php 
include("footers.php");
?>