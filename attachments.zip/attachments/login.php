<?php 
include("heading.php");
/* Header Section*/
?>
<!-- Content-->
 <?php
  /* php connection*/
 $con=mysqli_connect("localhost","root","","data");
  if(!$con)
   {
	die("connection not esstablish".mysqli_error($con));
	 } 
	 /* email login*/
     if(isset($_POST['submit']))
    {
	 $email=$_POST['email'];
	 $password=$_POST['password'];
	 $s="select * from data1 where email='$email' and password='$password'";
	 $result=mysqli_query($con,$s);
	 if(mysqli_num_rows($result)>0)
	 {
 $row = mysqli_fetch_array($result);
 $_SESSION['name']=$row['name'];
 $_SESSION['email']=$email;
 //jump to Dashboard page
header('location:dashboard.php'); 
	  }
else
{
	echo "invalid user name password".mysqli_error($con);
     }
       }
      ?>

<!--Anchor Tag-->
<a name=Logout></a>
</br>
<!--div Container   start-->                 
  <div class="container">
  <!--Heading section-->
    <h2  style="text-align:center">Log-in</h2>
	<!--form Section-->		
	<form class="form-horizontal"  method="post">
<!--User  Email-->								  
      <div class="form-group">
  <label class="control-label col-sm-4" for="email"   style=" font-size:12px;">User Name:</label>
  <div class="col-sm-4">
    <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
    </div>
    </div>
   <!--User Password--> 
  <div class="form-group">
 <label class="control-label col-sm-4" for="pwd" style=" font-size:12px;">Password:</label>
  <div class="col-sm-4">          
  <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password" required>
   </div>
   </div>
   <!--Submit Button-->
    <div class="form-group">        
   <div class="col-sm-offset-4 col-sm-10">
   <button type="submit" class="btn btn-default btn btn-primary"  name="submit">Submit</button></br></br>
<!--Sign Up  Link-->						  
<p  style="color:black; font-size:12px;"> if you don't have account  please<a href="signup.php"  style="color:black; font-size:12px;">	 sign up</a></p>
 </div>
 </div>
<!--form close-->
  </form>
  <!--Container Close-->
  </div>
  </br>
</br>
</br>
</br>
</br>     <!-- content close-->


<?php     
/*Footer Section*/
 include("footers.php")
 ?>


