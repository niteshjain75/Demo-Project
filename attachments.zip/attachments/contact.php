<?php
include("heading.php");
?>
<?php
if($_SESSION['email']==true)
{
echo "<p style='color:white;'>welcome"."".$_SESSION['name']."<p>";
}
else
{
header('location:login.php'); 

}
?>
<div class="container-fluid" style="text-indent:3.8em;">
<div class="row">
<div class="col-md-12" >
<h1 > Contact us</h1>
<h4> To contact us please fill the form below</h4>
</div>
</div>
</div>
<div class="container">
<div class="row">


<div class="col-md-6">
<form class="form-horizontal" method="post" >
<div class="form-group">
    <label for="exampleInputName2" style="font-size:12px;" >Name</label>
    <input type="text" class="form-control" id="exampleInputName2" placeholder="Name"  required style="width:500px;">
  </div>
 
  <div class="form-group">
      <label for="exampleInputName2"style="font-size:12px;" >Email</label>
   
      <input type="email" class="form-control" id="inputEmail3" placeholder="Email"   required style="width:500px;">
    
  </div>
  <div class="form-group">
    <label for="exampleInputName2" style="font-size:12px;" >Subjet</label>
    <input type="text" class="form-control" id="exampleInputName2" placeholder="Subjet"  required  style="width:500px;">
  </div>
  <div class="form-group">
    <label for="exampleInputName2"  style="font-size:12px;" >Message</label>
  <textarea class="form-control" rows="3"  required  style="width:500px;"></textarea>
  </div>
   <div class="form-group">
    <div class="col-sm-offset-3 col-sm-10">
      <button type="submit" class="btn btn-primary" >Submit</button>
    </div>
  </div>
</form>
  </div>
    





<div class="col-md-6">


<h4><b>TECHVIBRANT, INDIA</b></h4>
<address  style="font-size:14px;">
734 , 22nd Main, 12th Cross,</br>
JP Nagar 2nd Phase,</br>
Bangalore -560078, INDIA
</br>
Phone : +91 80 – 26499044</br>
Email: info@techvibrant.com
</address>
<iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d15556.177337681702!2d77.5818311!3d12.9048708!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1546434185513" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

</div>
</div>



















<?php 
include("footers.php");
?>