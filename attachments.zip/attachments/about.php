<?php 
include 'heading.php';
/*  Header Section*/
?>'
<!-- Content-->
  <!-- Div -->
<div>
  <!--   CONTAINER -->
 <div class="container">
  <!-- Heading  -->	  
	               <h1>About Us</h1>
 <!-- Paragraph    -->
		           <p>TechVibrant are an experienced team of software developers and IT professionals providing custom technical solutions and services to a global customer base. From start-ups to large organizations, we help companies build and manage their technologies allowing them to be more efficient.
				   </p>
                  </div>
	  <!-- Div  close -->  
                   </div>
  <!-- Div  class   CONTAINER -->
  <div class="container">
      <!-- row of columns -->
   <div class="row">
	<!--  row of columns  4 -->
   <div class="col-md-4">
   <!--  Heading -->
                     <h2>About TechVibrant</h2>
 <!-- Paragraph-->					
                  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. 
				  </p>
          <p>  
<!-- Anchor tag -->
		  <a class="btn btn-default" href="#" role="button">View details »</a>
		  </p>
<!--   columns  div close -->
        </div>
		   <!--  row of columns 4-->	
        <div class="col-md-4"> 
<!-- Heading Tag-->
                   <h2>Recent Articles</h2>
<!-- Paragraph tag-->					 
                     <p>Tellus ac cursus commodo, tortor mauris condimentum nibh,Donec id elit non mi porta gravida at eget metus. Fusce dapibus,  ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. 
					</p>
<!-- Anchor Tag -->
                    <p><a class="btn btn-default" href="#" role="button">View details »</a></p>
<!-- columns  div close-->
		              </div>
 <!--  row of columns 4 -->
		                <div class="col-md-4">
<!-- Heading Tag-->
			            <h2>Articles</h2>
<!-- Paragraph tag-->								
                        <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, fermentum massa justo sit amet risus.
						</p>
		<!-- Anchor Tag-->
          <p><a class="btn btn-default" href="#" role="button">View details »</a></p>
<!-- column div close -->
		  </div>
<!-- row of columns Close -->
        </div>
 <!-- Container Div close -->
      </div>
</br>
<!-- content close-->
<?php 
include 'footers.php';
/* Footer Section */
?>
