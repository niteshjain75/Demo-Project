

<?php
session_start();

session_unset();

if
(empty($_session["authenticated"])|| $_session["authenticated"]!='true'){
header('location:login.php');
}

session_destroy();
header('location:login.php');





?>