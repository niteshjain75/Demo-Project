<a name="signup"></a>
<?php
echo include("home.php");
?>
<?php 
session_start();


session_destroy();


?>