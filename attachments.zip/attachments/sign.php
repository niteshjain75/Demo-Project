
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
  
  </head>
<body>
</br>

<?php

 session_start();
$con=mysqli_connect("localhost","root","","data");
if(!$con)
{
	die("connection not esstablish".mysqli_error($con));
	
} 


if(isset($_POST['submit']))
{
$b=	$_POST['name'];
$c=	$_POST['email'];
$d=	$_POST['password'];

$f=	$_POST['address'];
$g=$_POST['city'];
$h=$_POST['number'];
$k="insert into data1(name,email,password,address,city,mobile)values('$b','$c','$d','$f','$g','$h')";
	header('location:fr.php'); 
if(mysqli_query($con,$k))
{
	echo"<script >  alert('Record Saved');  </script>  ";
}
	else
	{
		echo"<script> <alert>('error');</script>";
}
	
	
	
}
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-6"></br>
<a name= if you don't have account please sign up><img src="s.jpg" style="height:50%; width:100%"/> </a></div>
<div class="col-md-6"></br>
<form class="form-horizontal" method="post" style="margin-top:-20px;">
  <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge">Name</label>
    <div class="col-sm-6">
      <input class="form-control" type="text" id="formGroupInputLarge" placeholder="Enter your name" name="name">
    </div>
  </div>
 <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge"> Email</label>
    <div class="col-sm-6">
       <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email" name="email">
    </div>
  </div>
  <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge"> Password</label>
    <div class="col-sm-6">
      <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password">
   
    </div>
  </div>
  <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge"> Address</label>
    <div class="col-sm-6">
    <textarea class="form-control" rows="3" name="address" placeholder="Enter your address"></textarea>
    </div>
  </div>
   <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge"> City</label>
	<div class="col-sm-6">
  <select class="form-control" name="city">
  <option>Bangalore</option>
  <option>Mumbai</option>
  <option>Delhi</option>
  </select>
</div></div>
<div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge">Mobile no</label>
    <div class="col-sm-6">
      <input class="form-control" type="number" id="formGroupInputLarge" placeholder="Enter your name" name="number"></br>
   <button type="submit" class="btn btn-primary btn-lg " style=" text-align: center;" name="submit">Submit</button>
    </div>
  </div>
  </div>
    
</body>
</html>
  



