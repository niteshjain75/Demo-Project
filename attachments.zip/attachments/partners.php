<?php 
include("heading.php");

/* 	Header Section */
?> 
<?php
if($_SESSION['email']==true)
{
echo "<p style='color:white;'>welcome"."".$_SESSION['name']."<p>";
}
else
{
header('location:login.php'); 

}
?>
<a name=echo></a>

<?php 
/* Data base connect*/
$con=mysqli_connect("localhost","root","","data");
if(!$con)
{
	die("connection not esstablish".mysqli_error($con));
	
} 
if(isset($_GET['id'])) //checks if  id parameter is received or not
{
		
	$id=$_GET['id'];
	
	/*Delete  Query*/
 $s="delete from data2 where id='$id'";
if(mysqli_query($con,$s))
	echo "";
else
	echo "error".mysqli_error($con);
}
{
if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 10;
        $offset = ($pageno-1) * $no_of_records_per_page;
$total_pages_sql = "SELECT COUNT(*) FROM data2";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);

        $a = "SELECT * FROM  data2 LIMIT $offset, $no_of_records_per_page";
        $result = mysqli_query($con,$a);



	
}
?>
<?php




?>
<!-- POP UP -->
<script type='text/javascript'>
function confirmDelete()
{
   return confirm("Are you sure you want to delete this?");
}
</script>

<?php

		

/* Data Element*/
echo "  </br><div class='container'> <button type='submit' class='btn btn-success' ><a href='partner_addnew.php' style='color:white;'>Add </a></button> &nbsp;Partners</div></br>";
echo"<div class='container'>  <table  class='table table-bordered' style='font-size:14px;'><tr><th>Id</th><th>Name</th>  <th>EmailId</th> <th> Subject</th> <th>Mobile</th><th>Address</th><th> Action</th></tr>";
while($row=mysqli_fetch_array($result))
{
	$id=$row['id'];

	echo"<tr ><td>".$row['id']."</td><td>".$row['name']."</td><td>" .$row['email']."</td><td>".$row['subject']."</td><td>".$row['mobile']."</td><td>".$row['address']."</td>";
 echo "<td><a href='update.php?id=$id'><span class='glyphicon glyphicon-pencil' aria-hidden='true'  style='color:black; text-align:center; '></span> </a>/<a href='partners.php?id=$id' onclick='return confirmDelete()'><span class='glyphicon glyphicon-trash' aria-hidden='true'  style='color:black;'></span></a></td></tr>";  

}
echo"</table></div>";

	
?><div>
 <ul class="pagination">
           
        <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
        </li>
		<!--<li class="<?php if($pageno > 1){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno > 1){ echo '#'; } else { echo "?pageno=".($pageno +1); } ?>">2</a>
        </li>-->
        <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
        </li>
        <!--<li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>-->
		</li>
    </ul>
</div>

<?php 
include("footers.php");
/* Footer Section*/
?>