   <!-- Footer Class  container -->
<footer class="container-fluid bg-4 text-center">
<!-- Paragraph-->
  <p>©2018 TechVibrant.</p> 
     <!-- Footer tag close-->
</footer>
</body>
</html>
