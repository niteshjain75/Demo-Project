<?php 
 include("heading.php");
 /* Header Section*/
?>
<!-- Content-->

<?php

 /* Data Insert query*/
    $con=mysqli_connect("localhost","root","","data");
    if(!$con)
      {
	  die("connection not esstablish".mysqli_error($con));
	     } 
    if(isset($_POST ['submit']))
    {
      $b=	$_POST['name'];
      $c=	$_POST['email'];
      $d=	$_POST['password'];
      $f=	$_POST['address'];
      $g=   $_POST['city'];
      $h=   $_POST['number'];
     $k= "insert into data1(name,email,password,address,city,mobile)values('$b','$c','$d','$f','$g','$h')";
 if(mysqli_query($con,$k))
       {
  echo"<script >  alert('Record Saved');  </script> " ;
   }
else
	{
 echo"<script> alert('error');</script>";
     }
	 }
	
   ?>
    <?php
	/* After sign up  user jump to  Dashboard Page*/
      if(isset($_POST['submit']))
       {
   $email=    $_POST['email'];
   $password= $_POST['password'];
   
   $s="select * from data1 where email='$email' and password='$password' ";
   $result=mysqli_query($con,$s);
if(mysqli_num_rows($result)>0)
      {
    $row = mysqli_fetch_array($result);
   $_SESSION['name']=  $row['name'];
   $_SESSION['email']= $email;
   //jump to Dashboard page
   header("location:dashboard.php"); 
   }
   else
	{
	echo "invalid user name password".mysqli_error($con);
      }
       }
	  ?>
<!--- Container-fluid  Start -->
<div class="container-fluid">
<!-- Raw column -->
          <div class="row">
 <!--  column    col-md-6 -->												
	      <div class="col-md-6">
 <!--Put Image-->
           <a name= " sign up"><img src="sign.png" style=""/> </a>
<!--column col-md-6  close-->	 
		                    </div>
<!--column  col-md-6-->
            <div class="col-md-6">
<!--form validation using  java script-->
             <script type='text/javascript'>
function validateform(){  

var name=document.form.name.value;  
var email=document.form.email.value;  
var number=document.form.number.value;
var atposition=email.indexOf("@");  
var dotposition=email.lastIndexOf(".");  
 var password=document.form.password.value;  
 var address=document.form.address.value;  
 var city=document.form.city.value;
if (name==null || name==""){  
 document.getElementById("name").innerHTML="Name Mustbe fill";
  return false;  
}
else if(atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length){  
 
   alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
  return false;  
  }  

else if (isNaN(number)){  
  document.getElementById("numloc").innerHTML="Enter Numeric value only ";
  return false;
  
}
 
else if (number.length<10){  
     document.getElementById("loc").innerHTML=" minimum 10 digits";
  return false;  
}
else if (number ==null || number==""){  
 document.getElementById("num").innerHTML="not blank";
  return false;  }

else if (password.length<6){  
   document.getElementById("password").innerHTML="minimum 6 digit";
  return false;  
}

else if (address==null || address==""){  
document.getElementById("address").innerHTML="not blank";
  return false;  
}
else if (city==null || city==""){  
document.getElementById("city").innerHTML="not blank";
  return false;  
}


else {  
  return true;  
  }  
}    
 
</script>
<!--form-->
   <form  class="form-horizontal"  name="form" method="post" onsubmit="return validateform()" >
  <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge"  style="font-size:12px; font-weight: bold;">Name</label>
    <div class="col-sm-6">
      <input class="form-control" type="text" id="formGroupInputLarge" placeholder="Enter your name" required name="name" > <span id="name" style="color: red; font-size:8px; " >
    </div>
  </div>
 <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge"  style="font-size:12px;"  > Email</label>
    <div class="col-sm-6">
       <input type="email" class="form-control" id="exampleInputEmail1" required  placeholder="Email" name="email" ><span id="email" style="color: red; font-size:8px; " >
    </div>
  </div>
  <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge" style="font-size:12px;" > Password</label>
    <div class="col-sm-6">
   <input type="password" class="form-control" id="exampleInputPassword1" required  placeholder="Password" name="password" >
   <span id="password" style="color: red; font-size:8px; " >
  </div>
  </div>
  <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge" style="font-size:12px;"  > Address</label>
    <div class="col-sm-6">
    <textarea class="form-control" rows="3" name="address" required placeholder="Enter your address"></textarea><span id="address" style="color: red; font-size:8px; " >
    </div>
  </div>
   <div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge" style="font-size:12px;" > City</label>
	<div class="col-sm-6">
  <select class="form-control" name="city" required>
   <option></option>
  <option>Bangalore</option>
  <option>Mumbai</option>
  <option>Delhi</option>
  <span id="city" style="color: red; font-size:8px; " >
  </select>
</div></div>
<div class="form-group form-group-lg">
    <label class="col-sm-4 control-label" for="formGroupInputLarge" style="font-size:12px;"  >Mobile no</label>
    <div class="col-sm-6">
      <input class="form-control" type="text" required placeholder="Enter your name" name="number"  ><span id="numloc" style="color: red; font-size:8px; " ></span>  <span id="num"  style="color: red; font-size:8px; " ></span>  <span id="loc"  style="color: red; font-size:8px; "  ></span> </br>
   <button type="submit" class="btn btn-primary btn-lg " style=" text-align: center;" name="submit" onclick='return validateform()'>Submit</button>
    </div>
  </div>
  </div>
    </form>
</div>
<!--form  close-->
<?php
/* footer  section*/
 include("footers.php");
?>
