<?php
/*  HEADER Section*/ 
                  include("heading.php");
?>
<?php
/*session  confirm*/
if($_SESSION['email']==true)
{
echo "<p style='color:white;'>welcome"."".$_SESSION['name']."<p>";
}
else
{
header('location:login.php'); 

}
?>
<!-- content-->
<?php
 /*  Record Insert  query */
$con=mysqli_connect("localhost","root","","data");
if(!$con)
{
	die("connection not esstablish".mysqli_error($con));
	
} 

if(isset($_POST['submit']))
{
$b=	$_POST['name'];
$c=	$_POST['email'];


$f=	$_POST['subject'];
$g=$_POST['number'];
$h=$_POST['address'];
/*insert  data query*/
$k="insert into data2(name,email,subject,mobile,address)values('$b','$c','$f','$g','$h')";
	if(mysqli_query($con,$k))
{
	echo"<script >  alert('Record Saved');  </script>   " ;
}
	else
	{
		echo"<script> <alert>('error');</script>";
}

	}
	
?>
<script type='text/javascript'>
function validateform(){  

var name=document.form.name.value;  
var email=document.form.email.value;  
var number=document.form.number.value;
var atposition=email.indexOf("@");  
var dotposition=email.lastIndexOf(".");  
 var subject=document.form.subject.value;  
 var address=document.form.address.value;  
if (name==null || name==""){  
 document.getElementById("business").innerHTML="Name Mustbe fill";
  return false;  
}
else if(atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length){  
 
   alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
  return false;  
  }  

else if (isNaN(number)){  
  document.getElementById("numloc").innerHTML="Enter Numeric value only ";
  return false;
  
}
 
else if (number.length<10){  
     document.getElementById("loc").innerHTML=" minimum 10 digits";
  return false;  
}
else if (number ==null || number==""){  
 document.getElementById("num").innerHTML="not blank";
  return false;  }

else if (subject==null || subject==""){  
   document.getElementById("subject").innerHTML="not blank";
  return false;  
}

else if (address==null || address==""){  
document.getElementById("add").innerHTML="not blank";
  return false;  
}


else {  
  return true;  
  }  
}    
 
</script>

<!--  Div Class (container)-->
<div class="container main-content">

<!--  Heading TAG   <H1>-->
                             <h1>Partner - Add New </h1>


<!--  Div Class (raw)-->

<div class="row">

<!--  form   for  add partners  -->
                             
<div class="col-md-6">
   <form class="form-horizontal" name="form" method="post"  onsubmit="return validateform()"  >
<div class="form-group">
<!--   Name     -->
                     <label for="exampleInputName2" style="font-size:12px;" >	Business Name</label>
                     <input type="text" class="form-control" id="exampleInputName2" placeholder="Name"  name="name"  style="width:450px;"><span id="business" style="color: red; font-size:12px; " >
  </div>
 <!-- Email-->
  <div class="form-group">
                        <label for="exampleInputName2"style="font-size:12px;" >Company Email</label>
                        <input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Email"  style="width:450px;"> <span id="email" style="color: red; font-size:12px; " >   
  </div>
<!--  Mobile Number  -->
 <div class="form-group">
                           <label for="exampleInputName2" style="font-size:12px;" >	Mobile Number</label>
                           <input type="text" class="form-control" id="exampleInputName2" placeholder="Enter your Number"      name="number" style="width:450px;"><span id="numloc" style="color: red; font-size:12px; " ></span>  <span id="num"  style="color: red; font-size:12px; " ></span>  <span id="loc"  style="color: red; font-size:12px; "  ></span>
  </div>
  <!--  Close Div  class = "col-md-6"-->
</div>
 <!--  Div  class = "col-md-6"-->
      <div class="col-md-6"  >
    <!--  Subject-->
                    <div class="form-group">
                    <label for="exampleInputName2" style="font-size:12px;" >	Subject</label>
                    <input type="text" class="form-control" id="exampleInputName2" placeholder="Subject"  name="subject"   style="width:450px;"><span id="subject" style="color: red; font-size:12px; " >   
                       </div>
   

   <!--  Address    -->
                           <div class="form-group ">
                           <label class=" control-label" for="formGroupInputLarge" style="font-size:12px;" > Address</label>
                          <textarea class="form-control" rows="4" name="address" placeholder="Enter your address"   style="width:450px;"></textarea> <span id="add"  style="color: red; font-size:12px; " >
                           </div>
  
 <!--  Close Div  class = "col-md-6"-->
</div>
</div>  
 <!--  Close Div-->
	</div>
	 <!--  Div Container-->
	         <div  class="container" >
	         <div class="row">
			 
	 <!--  div class="col-md-12"-->		 
                                   <div class="col-sm-12"    style="text-align:right;" >
      <!--   Save  Button    -->
	  <button type="submit" class="btn btn-success" name="submit" onsubmit="return validateform()" >Save</button>
	  
	  <!--  Clear Button's  -->
	   <button type="submit" class="btn btn-primary" name="clear">Clear</button>
	   </form>
	   </div>
     </div>
	 <!--  form tag close-->
  </div>
	 <!--  Close Div  -->
	 </div>
	
	 <!-- content  close-->
<?php 
include("footers.php");
/* footer Section  */ 

?>